<!DOCTYPE html>
<html>
<head>
    <title>Energia Sustentável</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <link rel="script" href="script.js">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="topnav">
        <a class="active" href="#home">Principal</a>
        <a href="./consumo.html">Consumo</a>
        <a href="#contact">Sugestão</a>
        <a href="./sobre.html">Sobre</a>
    </div>
    <div class="central">
        <header class="rigthimg">
            <div class="Marcador"></div>
            <h1 class="text_img">Energia Sustentável</h1>
        </header>
        <p>Porquê é tão importante discutir sobre energia e seus impactos ambientais</p>
    </div>
    <div class="central">
        <img src="Imagens/R (5).jpeg" width="100%">
    </div>

    <div class="conteudo">
    <h2>A Existência da Eficiência Energética</h2>
<div class="rigthimg">
    <p>Para situar você no contexto de Energia Sustentável precisamos falar sobre a Eficiência Energética, sempre vemos na TV e na mídia sobre poluição gerada por combustiveis não renováveis e suas consequências, porém pouco se fala de uma eficiência energética, isto é, o quanto o produto que você utiliza é eficiênte, mas fala apena lembrar, que  não é apenas nisso que o contexto da eficiência energética está inserida.</p>
    <p>A um contexto bastante filosófico por trás disso é "Fazer do pouco, muito", a ideia é simples, menos energia mais trabalho, a dificuldade está na implementação e na inovação dos produtos, uma curiosidade é que depois da Lei de Energia em 2007 Estabelecendo novas rigorosas metas de eficiência energética que entrou em vigor em 2012-2014 (primeira fase), e entrou esse conceito nas lâmpadas em que a eficiência delas deveria ser aproximadamnte 30% mais eficientes, E uma dessas consequência direta dessa lei foi o incentivo para produzir lâmpadas capazes de cumprir as normas.</p>
    <img src="Imagens/Eficiencia_img.png" width="400px">
</div>
<div class="Entre_Topico"></div>
<h2>Um pouco de Física</h2>
<div>
   <p></p>
</div>
    </div>
</body>
</html>